-- Create User table
CREATE TABLE User (
    Uname VARCHAR(250),
    UEmail VARCHAR(250) PRIMARY KEY,
    USDT INT
);

-- Create Job table
CREATE TABLE Job (
    JType VARCHAR(250),
    Jname VARCHAR(250),
    JSalary MONEY,
    Jcompany VARCHAR(250),
    Jlocation VARCHAR(250),
    JRole VARCHAR(250)
);

-- Create Apply table
CREATE TABLE Apply (
    Uname VARCHAR(250),
    Jname VARCHAR(250),
    Jcompany VARCHAR(250),
    JRole VARCHAR(250),
    FOREIGN KEY (Uname) REFERENCES User(Uname),
    FOREIGN KEY (Jname, Jcompany) REFERENCES Job(Jname, Jcompany)
);
